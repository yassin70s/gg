from django.apps import AppConfig


class VristoDjangoConfig(AppConfig):
    name = 'vristoDjango'
